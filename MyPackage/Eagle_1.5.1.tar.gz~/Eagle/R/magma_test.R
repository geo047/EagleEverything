

magma_test <- function( )
{  
  ## magma test code  
  ## starting off simple
 
  mg <- magma_test_rcpp( )
   
}  ## end function



   
   

